import json
import os
import tkinter as tk
from tkinter import messagebox

# Fájl neve ugyanabban a mappában, ahol a script van
script_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(script_dir, "reaperosdata.json")

# GUI létrehozása
root = tk.Tk()
root.title("Setup")
root.geometry("400x200")
root.configure(bg="black")

label = tk.Label(root, text="Add meg a felhasználóneved:", fg="white", bg="black", font=("Courier", 14))
label.pack(pady=20)

username_entry = tk.Entry(root, font=("Courier", 14), bg="gray20", fg="white", insertbackground="white")
username_entry.pack(pady=10)

def save_data():
    username = username_entry.get().strip()
    if not username:
        messagebox.showwarning("Hiba", "Kérlek, adj meg egy felhasználónevet!")
        return

    data = {"Username": username, "setupcompleted": True}

    try:
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
        messagebox.showinfo("Kész", f"Setup kész!\nMentve ide: {file_path}")
    except Exception as e:
        messagebox.showerror("Hiba", f"Hiba a mentés közben:\n{e}")

save_button = tk.Button(root, text="MENTÉS", command=save_data, font=("Courier", 14), bg="blue", fg="white")
save_button.pack(pady=20)

root.mainloop()
